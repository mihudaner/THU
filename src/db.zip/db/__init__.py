#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2024/1/18 15:49
# @Author  : mihudan~
# @File    : __init__.py
# @Description : 

def print_hi(name):
    print(f'Hi, {name}')


if __name__ == '__main__':
    print_hi('Python')
